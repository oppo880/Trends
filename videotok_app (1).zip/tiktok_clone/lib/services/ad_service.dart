import 'dart:io';
import 'package:google_mobile_ads/google_mobile_ads.dart';

/// All AdMob ad logic in one place.
/// TEST IDs are used here — replace with your own AdMob unit IDs before release.
class AdService {
  static final AdService instance = AdService._();
  AdService._();

  // ----- Ad unit IDs (Google test IDs — swap with your real ones) -----
  String get bannerId => Platform.isAndroid
      ? 'ca-app-pub-3940256099942544/6300978111'
      : 'ca-app-pub-3940256099942544/2934735716';

  String get interstitialId => Platform.isAndroid
      ? 'ca-app-pub-3940256099942544/1033173712'
      : 'ca-app-pub-3940256099942544/4411468910';

  String get rewardedId => Platform.isAndroid
      ? 'ca-app-pub-3940256099942544/5224354917'
      : 'ca-app-pub-3940256099942544/1712485313';

  InterstitialAd? _interstitial;
  int _videosWatched = 0;

  Future<void> init() async {
    await MobileAds.instance.initialize();
    _loadInterstitial();
  }

  void _loadInterstitial() {
    InterstitialAd.load(
      adUnitId: interstitialId,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) => _interstitial = ad,
        onAdFailedToLoad: (_) => _interstitial = null,
      ),
    );
  }

  /// Shows a full-screen ad after every 5th video — classic short-video monetization.
  void maybeShowInterstitial() {
    _videosWatched++;
    if (_videosWatched % 5 == 0 && _interstitial != null) {
      _interstitial!.show();
      _interstitial = null;
      _loadInterstitial();
    }
  }

  /// Rewarded ad: user watches ad -> earns coins.
  Future<void> showRewarded({required void Function(int amount) onEarned}) async {
    await RewardedAd.load(
      adUnitId: rewardedId,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          ad.fullScreenContentCallback = FullScreenContentCallback(
            onAdDismissedFullScreenContent: (ad) => ad.dispose(),
          );
          ad.show(onUserEarnedReward: (ad, reward) {
            onEarned(reward.amount.toInt());
          });
        },
        onAdFailedToLoad: (_) {},
      ),
    );
  }

  BannerAd createBanner() {
    return BannerAd(
      adUnitId: bannerId,
      size: AdSize.banner,
      request: const AdRequest(),
      listener: const BannerAdListener(),
    )..load();
  }
}
