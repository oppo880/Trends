import 'package:flutter/material.dart';
import '../services/ad_service.dart';

class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key});
  @override
  State<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  int _coins = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(title: const Text('আমার ইনকাম'), backgroundColor: Colors.black),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('মোট কয়েন', style: TextStyle(color: Colors.grey, fontSize: 16)),
            Text('$_coins 🪙', style: const TextStyle(color: Colors.white, fontSize: 48, fontWeight: FontWeight.bold)),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: () {
                AdService.instance.showRewarded(onEarned: (amount) {
                  setState(() => _coins += amount * 10); // 1 reward = 10 coins
                });
              },
              icon: const Icon(Icons.play_circle, color: Colors.white),
              label: const Text('বিজ্ঞাপন দেখে কয়েন অর্জন করুন', style: TextStyle(color: Colors.white)),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.pink, padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14)),
            ),
            const SizedBox(height: 16),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 32),
              child: Text(
                'টাকা তুলতে হলে Google AdMob-এ আপনার নিজের অ্যাকাউন্ট খুলে real ad unit ID বসাতে হবে। ইনকাম AdMob-এর মাধ্যমে ব্যাংকে আসবে।',
                style: TextStyle(color: Colors.grey, fontSize: 12),
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
