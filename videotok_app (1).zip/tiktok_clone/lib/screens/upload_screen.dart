import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class UploadScreen extends StatefulWidget {
  const UploadScreen({super.key});
  @override
  State<UploadScreen> createState() => _UploadScreenState();
}

class _UploadScreenState extends State<UploadScreen> {
  XFile? _pickedVideo;
  final _caption = TextEditingController();

  Future<void> _pickVideo() async {
    final picked = await ImagePicker().pickVideo(source: ImageSource.gallery);
    if (picked != null) setState(() => _pickedVideo = picked);
  }

  void _publish() {
    if (_pickedVideo == null) return;
    // TODO: upload to Firebase Storage / Supabase, then save metadata to DB.
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('পাবলিশ হচ্ছে... (এখানে backend সংযোগ করুন)')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('নতুন ভিডিও'), backgroundColor: Colors.black),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Expanded(
              child: GestureDetector(
                onTap: _pickVideo,
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.grey[900],
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.grey),
                  ),
                  child: Center(
                    child: Text(
                      _pickedVideo == null
                          ? '🎬 ভিডিও সিলেক্ট করতে ট্যাপ করুন'
                          : '✅ ${_pickedVideo!.name}',
                      style: const TextStyle(color: Colors.white),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _caption,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(
                hintText: 'ক্যাপশন লিখুন...',
                hintStyle: TextStyle(color: Colors.grey),
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: _publish,
              style: ElevatedButton.styleFrom(backgroundColor: Colors.pink),
              child: const Text('পাবলিশ করুন', style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }
}
